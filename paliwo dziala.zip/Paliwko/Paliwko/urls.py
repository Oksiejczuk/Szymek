from django.contrib import admin
from django.urls import path
from paliwo.views import    welcome
from paliwo.views import dodaj
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', welcome, name="welcome"),
    path('dodaj', dodaj, name="dodaj")
]
