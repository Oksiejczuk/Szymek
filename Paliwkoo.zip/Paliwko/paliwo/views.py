from django.shortcuts import render
from .forms import Liczby
from paliwo.models import Paliwo

def dodaj(request):
    form=Liczby()
    if request.method=="POST":
        pole1=request.POST['pole1']
        pole2=request.POST['pole2']
        suma=int(pole1)+int(pole2)
        context={
            "pole1":pole1,
            "pole2":pole2,
            "suma":suma,
            "form":form,
        }
        return render(request,'dodaj.html',context)
    return render(request,'dodaj.html',{"form":form})
def welcome(request):
    pal = Paliwo.objects.all()

    return render(request,"welcome.html",{"pal":pal})

