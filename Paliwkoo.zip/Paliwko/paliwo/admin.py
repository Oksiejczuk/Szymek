from django.contrib import admin
from paliwo.models import Paliwo
admin.site.register(Paliwo)
