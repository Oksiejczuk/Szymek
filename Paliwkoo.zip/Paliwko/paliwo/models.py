from django.db import models

class Paliwo(models.Model):
    rodzaj_paliwa = models.TextField()
    cena= models.FloatField()

